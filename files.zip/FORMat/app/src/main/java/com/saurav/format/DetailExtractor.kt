package com.saurav.format

/**
 * Pulls common personal details out of free-form text using pattern
 * matching - no internet, no ML model, no account needed. Works best when
 * fields are labeled (e.g. "Name: John Smith", "DOB: 12/05/1990") but also
 * makes a best effort on plainer prose (e.g. "John Smith is a 34-year-old
 * engineer...").
 */
object DetailExtractor {

    data class Result(
        val name: String? = null,
        val age: String? = null,
        val gender: String? = null,
        val dob: String? = null,
        val address: String? = null,
        val email: String? = null,
        val phone: String? = null,
        val nationality: String? = null,
        val bloodGroup: String? = null,
        val maritalStatus: String? = null
    ) {
        fun isEmpty(): Boolean {
            return listOf(name, age, gender, dob, address, email, phone, nationality, bloodGroup, maritalStatus)
                .all { it.isNullOrBlank() }
        }
    }

    private val monthNames = "January|February|March|April|May|June|July|August|September|October|November|December|" +
            "Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec"

    fun extract(rawText: String): Result {
        val text = rawText.trim()

        return Result(
            name = extractName(text),
            age = extractAge(text),
            gender = extractGender(text),
            dob = extractDob(text),
            address = extractAddress(text),
            email = extractEmail(text),
            phone = extractPhone(text),
            nationality = extractLabeled(text, listOf("Nationality")),
            bloodGroup = extractBloodGroup(text),
            maritalStatus = extractLabeled(text, listOf("Marital Status", "Marital status"))
        )
    }

    // ---------- Email (most reliable - simple, unambiguous pattern) ----------

    private fun extractEmail(text: String): String? {
        val regex = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
        return regex.find(text)?.value
    }

    // ---------- Phone / Contact number ----------

    private fun extractPhone(text: String): String? {
        // Prefer an explicitly labeled number first
        val labeled = extractLabeled(text, listOf("Phone", "Mobile", "Contact Number", "Contact No", "Contact", "Ph", "Cell"))
        if (!labeled.isNullOrBlank()) {
            val digits = Regex("[\\d+][\\d\\s-]{7,}\\d").find(labeled)
            if (digits != null) return digits.value.trim()
        }
        // Fallback: bare Indian-style 10-digit mobile number, optionally with +91
        val bare = Regex("(?:\\+91[\\-\\s]?)?\\b[6-9]\\d{9}\\b").find(text)
        if (bare != null) return bare.value.trim()
        // Broader fallback: any run of 10+ digits (with optional separators/plus)
        val generic = Regex("\\+?\\d[\\d\\s-]{8,}\\d").find(text)
        return generic?.value?.trim()
    }

    // ---------- Age ----------

    private fun extractAge(text: String): String? {
        val labeled = Regex("\\bAge\\b\\s*[:\\-]?\\s*(\\d{1,3})", RegexOption.IGNORE_CASE).find(text)
        if (labeled != null) return labeled.groupValues[1]

        val phrased = Regex("\\b(\\d{1,3})\\s*[- ]?(years old|yrs old|years of age|yrs\\.?)\\b", RegexOption.IGNORE_CASE).find(text)
        if (phrased != null) return phrased.groupValues[1]

        val hyphenated = Regex("\\b(\\d{1,3})[- ]year[- ]old\\b", RegexOption.IGNORE_CASE).find(text)
        return hyphenated?.groupValues?.get(1)
    }

    // ---------- Gender (explicit mentions only - no pronoun guessing) ----------

    private fun extractGender(text: String): String? {
        val labeled = extractLabeled(text, listOf("Gender", "Sex"))
        if (!labeled.isNullOrBlank()) {
            val normalized = normalizeGenderWord(labeled)
            if (normalized != null) return normalized
        }
        val standalone = Regex("\\b(Male|Female|Transgender|Non-binary|Nonbinary)\\b", RegexOption.IGNORE_CASE).find(text)
        return standalone?.value?.let { normalizeGenderWord(it) }
    }

    private fun normalizeGenderWord(raw: String): String? {
        val cleaned = raw.trim().trimEnd('.', ',').lowercase()
        return when {
            cleaned.startsWith("m") && cleaned.contains("male") -> "Male"
            cleaned == "m" -> "Male"
            cleaned.startsWith("f") && cleaned.contains("female") -> "Female"
            cleaned == "f" -> "Female"
            cleaned.contains("trans") -> "Transgender"
            cleaned.contains("non-binary") || cleaned.contains("nonbinary") -> "Non-binary"
            else -> null
        }
    }

    // ---------- Date of Birth ----------

    private fun extractDob(text: String): String? {
        // Look for a date near a DOB-style label first (higher confidence)
        val labelRegex = Regex("(?:DOB|Date of Birth|Born on|Born)\\s*[:\\-]?\\s*([^\\n,;]{6,25})", RegexOption.IGNORE_CASE)
        val labelMatch = labelRegex.find(text)
        if (labelMatch != null) {
            val nearbyDate = findDatePattern(labelMatch.groupValues[1])
            if (nearbyDate != null) return nearbyDate
        }
        // Fallback: first date-like pattern anywhere in the text
        return findDatePattern(text)
    }

    private fun findDatePattern(segment: String): String? {
        val numeric = Regex("\\b\\d{1,2}[\\/\\-.]\\d{1,2}[\\/\\-.]\\d{2,4}\\b").find(segment)
        if (numeric != null) return numeric.value

        val dayMonthYear = Regex("\\b\\d{1,2}\\s+($monthNames)\\.?,?\\s+\\d{4}\\b", RegexOption.IGNORE_CASE).find(segment)
        if (dayMonthYear != null) return dayMonthYear.value

        val monthDayYear = Regex("\\b($monthNames)\\.?\\s+\\d{1,2},?\\s+\\d{4}\\b", RegexOption.IGNORE_CASE).find(segment)
        return monthDayYear?.value
    }

    // ---------- Address ----------

    private fun extractAddress(text: String): String? {
        val labelRegex = Regex(
            "(?:Address)\\s*[:\\-]\\s*(.+?)(?=\\n\\s*\\n|\\b(?:Email|Phone|Mobile|Contact|DOB|Date of Birth|Age|Gender|Nationality)\\b|$)",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        val labeled = labelRegex.find(text)?.groupValues?.get(1)?.trim()
        if (!labeled.isNullOrBlank() && labeled.length in 5..200) return labeled.trim(',', ' ', '\n')

        // Fallback: a sentence/line containing a 6-digit PIN code plus an address-ish keyword
        val pinLine = text.lines().firstOrNull { line ->
            Regex("\\b\\d{6}\\b").containsMatchIn(line) &&
                    Regex("street|road|nagar|colony|sector|city|state|pin|pincode|marg|lane|apartment|block", RegexOption.IGNORE_CASE).containsMatchIn(line)
        }
        return pinLine?.trim()
    }

    // ---------- Name ----------

    private fun extractName(text: String): String? {
        val labelRegex = Regex("(?:Full Name|Name)\\s*[:\\-]\\s*([A-Z][a-zA-Z.'-]*(?:\\s+[A-Z][a-zA-Z.'-]*){0,3})")
        val labeled = labelRegex.find(text)
        if (labeled != null) return labeled.groupValues[1].trim()

        val phrased = Regex("(?:My name is|I am|I'm|This is)\\s+([A-Z][a-zA-Z.'-]*(?:\\s+[A-Z][a-zA-Z.'-]*){0,3})")
        val phrasedMatch = phrased.find(text)
        if (phrasedMatch != null) return phrasedMatch.groupValues[1].trim()

        // Fallback: a capitalized 2-4 word sequence near the very start of the text
        val stopWords = setOf("The", "This", "My", "I", "A", "An", "He", "She", "They", "It", "We", "You")
        val leading = Regex("^([A-Z][a-zA-Z.'-]*(?:\\s+[A-Z][a-zA-Z.'-]*){1,3})").find(text.trim())
        if (leading != null) {
            val candidate = leading.groupValues[1].trim()
            val firstWord = candidate.split(" ").first()
            if (firstWord !in stopWords) return candidate
        }
        return null
    }

    // ---------- Blood group ----------

    private fun extractBloodGroup(text: String): String? {
        val labeled = extractLabeled(text, listOf("Blood Group", "Blood group"))
        if (!labeled.isNullOrBlank()) {
            val match = Regex("\\b(A|B|AB|O)\\s*([+-]|positive|negative)\\b", RegexOption.IGNORE_CASE).find(labeled)
            if (match != null) return formatBloodGroup(match)
        }
        val standalone = Regex("\\b(A|B|AB|O)\\s*([+-]|positive|negative)\\b", RegexOption.IGNORE_CASE).find(text)
        return standalone?.let { formatBloodGroup(it) }
    }

    private fun formatBloodGroup(match: MatchResult): String {
        val group = match.groupValues[1].uppercase()
        val sign = match.groupValues[2].lowercase()
        val symbol = when {
            sign.startsWith("pos") || sign == "+" -> "+"
            sign.startsWith("neg") || sign == "-" -> "-"
            else -> ""
        }
        return "$group$symbol"
    }

    // ---------- Generic "Label: value" extractor used by several fields ----------

    private fun extractLabeled(text: String, labels: List<String>): String? {
        for (label in labels) {
            val regex = Regex("\\b${Regex.escape(label)}\\s*[:\\-]\\s*([^\\n,;]{1,60})", RegexOption.IGNORE_CASE)
            val match = regex.find(text)
            if (match != null) return match.groupValues[1].trim()
        }
        return null
    }
}
