# FORMat — Android source project

Paste any paragraph, page of text, form content, or bio into the box and
tap "Extract Details" — it pulls out and labels:

1. Name
2. Age
3. Gender
4. Date of Birth
5. Address
6. Email ID
7. Contact Number
8. Nationality
9. Blood Group
10. Marital Status

Any field it can't find is simply left off the results - no "N/A" clutter.
Tap "Copy Results" to copy everything found as a clean labeled list.

## Zero permissions, zero accounts, zero internet needed

This works entirely through pattern matching on the text you paste - no
network calls, no ML model, no third-party service of any kind. It's the
simplest of all your apps so far and should build without any surprises.

## How it decides what's what

- **Email, phone, blood group**: matched by clear patterns (e.g.
  `name@domain.com`, 10-digit mobile numbers)
- **Name, age, gender, DOB, address, nationality, marital status**: first
  looks for an explicit label ("Name:", "DOB:", "Address:", etc.) since
  that's the most reliable signal; falls back to reasonable pattern-based
  guesses in plain prose in a few cases (name, age, date)
- **Gender** is only ever filled in from an explicit mention (a label or
  the words "Male"/"Female"/etc. appearing in the text) - never guessed
  from pronouns, to avoid incorrect assumptions

This is pattern-matching, not true language understanding, so it works
best on text that at least loosely resembles a form, ID card, or
biography - free-flowing casual text with no structure at all will
naturally yield fewer matches.

## Building the APK (same GitHub Actions routine as your other apps)

1. Zip this whole `FORMat` folder.
2. Create a new GitHub repo, upload the zip as `files.zip`.
3. Add `.github/workflows/build.yml` (provided alongside this project).
4. Push → **Actions** tab → wait for ✅ → download from **Artifacts** →
   extract → install `app-debug.apk`.

This project already includes a fixed debug keystore, so future rebuilds
keep the same signature and install directly over old versions.
