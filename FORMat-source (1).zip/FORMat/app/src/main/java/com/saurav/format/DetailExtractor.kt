package com.saurav.format

/**
 * Pulls common personal details out of free-form text using pattern
 * matching - no internet, no ML model, no account needed. Works best when
 * fields are labeled (e.g. "Name: John Smith", "DOB: 12/05/1990") but also
 * makes a best effort on plainer prose (e.g. "John Smith is a 34-year-old
 * engineer...").
 */
object DetailExtractor {

    data class Result(
        val name: String? = null,
        val fatherName: String? = null,
        val age: String? = null,
        val gender: String? = null,
        val dob: String? = null,
        val address: String? = null,
        val email: String? = null,
        val phone: String? = null,
        val nationality: String? = null,
        val bloodGroup: String? = null,
        val maritalStatus: String? = null,
        val occupation: String? = null,
        val education: String? = null
    ) {
        fun isEmpty(): Boolean {
            return listOf(
                name, fatherName, age, gender, dob, address, email, phone,
                nationality, bloodGroup, maritalStatus, occupation, education
            ).all { it.isNullOrBlank() }
        }
    }

    private val monthNames = "January|February|March|April|May|June|July|August|September|October|November|December|" +
            "Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec"

    // Stops name-capturing before Indian-style relation markers like "S/o", "D/o",
    // "W/o", "C/o", "R/o" so they don't get swallowed into a name.
    private const val RELATION_MARKER_LOOKAHEAD = "(?!(?:[SDWCR]\\/[Oo]\\b))"
    private val NAME_WORD = "[A-Z][a-zA-Z.'-]*"
    private val NAME_CONTINUATION = "(?:\\s+$RELATION_MARKER_LOOKAHEAD$NAME_WORD){0,3}"

    private val commonNationalities = listOf(
        "Indian", "American", "British", "Canadian", "Australian", "Pakistani", "Bangladeshi",
        "Nepali", "Sri Lankan", "Chinese", "Japanese", "Korean", "German", "French", "Italian",
        "Spanish", "Russian", "Nigerian", "Brazilian", "Mexican", "Emirati", "Saudi", "Filipino",
        "Indonesian", "Malaysian", "Singaporean", "Thai", "Vietnamese", "Egyptian", "South African",
        "Kenyan", "Turkish"
    )

    private val commonOccupations = listOf(
        "student", "engineer", "doctor", "teacher", "farmer", "businessman", "businesswoman",
        "employee", "lawyer", "nurse", "professor", "manager", "clerk", "officer", "driver",
        "accountant", "developer", "designer", "scientist", "researcher", "architect",
        "consultant", "salesman", "shopkeeper", "housewife", "entrepreneur"
    )

    fun extract(rawText: String): Result {
        val text = rawText.trim()

        return Result(
            name = extractName(text),
            fatherName = extractFatherName(text),
            age = extractAge(text),
            gender = extractGender(text),
            dob = extractDob(text),
            address = extractAddress(text),
            email = extractEmail(text),
            phone = extractPhone(text),
            nationality = extractNationality(text),
            bloodGroup = extractBloodGroup(text),
            maritalStatus = extractMaritalStatus(text),
            occupation = extractOccupation(text),
            education = extractEducation(text)
        )
    }

    // ---------- Email ----------

    private fun extractEmail(text: String): String? {
        val regex = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
        return regex.find(text)?.value
    }

    // ---------- Phone / Contact number ----------

    private fun extractPhone(text: String): String? {
        val labeled = extractLabeled(text, listOf("Phone", "Mobile", "Contact Number", "Contact No", "Contact", "Ph", "Cell"))
        if (!labeled.isNullOrBlank()) {
            val digits = Regex("[\\d+][\\d\\s-]{7,}\\d").find(labeled)
            if (digits != null) return digits.value.trim()
        }
        val bare = Regex("(?:\\+91[\\-\\s]?)?\\b[6-9]\\d{9}\\b").find(text)
        if (bare != null) return bare.value.trim()
        val generic = Regex("\\+?\\d[\\d\\s-]{8,}\\d").find(text)
        return generic?.value?.trim()
    }

    // ---------- Age ----------

    private fun extractAge(text: String): String? {
        val labeled = Regex("\\bAge\\b\\s*[:\\-]?\\s*(\\d{1,3})", RegexOption.IGNORE_CASE).find(text)
        if (labeled != null) return labeled.groupValues[1]

        val phrased = Regex("\\b(\\d{1,3})\\s*[- ]?(years old|yrs old|years of age|yrs\\.?)\\b", RegexOption.IGNORE_CASE).find(text)
        if (phrased != null) return phrased.groupValues[1]

        val hyphenated = Regex("\\b(\\d{1,3})[- ]year[- ]old\\b", RegexOption.IGNORE_CASE).find(text)
        return hyphenated?.groupValues?.get(1)
    }

    // ---------- Gender (explicit mentions only - no pronoun guessing) ----------

    private fun extractGender(text: String): String? {
        val labeled = extractLabeled(text, listOf("Gender", "Sex"))
        if (!labeled.isNullOrBlank()) {
            val normalized = normalizeGenderWord(labeled)
            if (normalized != null) return normalized
        }
        val standalone = Regex("\\b(Male|Female|Transgender|Non-binary|Nonbinary)\\b", RegexOption.IGNORE_CASE).find(text)
        return standalone?.value?.let { normalizeGenderWord(it) }
    }

    private fun normalizeGenderWord(raw: String): String? {
        val cleaned = raw.trim().trimEnd('.', ',').lowercase()
        return when {
            cleaned.startsWith("m") && cleaned.contains("male") -> "Male"
            cleaned == "m" -> "Male"
            cleaned.startsWith("f") && cleaned.contains("female") -> "Female"
            cleaned == "f" -> "Female"
            cleaned.contains("trans") -> "Transgender"
            cleaned.contains("non-binary") || cleaned.contains("nonbinary") -> "Non-binary"
            else -> null
        }
    }

    // ---------- Date of Birth ----------

    private fun extractDob(text: String): String? {
        val labelRegex = Regex("(?:DOB|Date of Birth|Born on|Born)\\s*[:\\-]?\\s*([^\\n,;]{6,25})", RegexOption.IGNORE_CASE)
        val labelMatch = labelRegex.find(text)
        if (labelMatch != null) {
            val nearbyDate = findDatePattern(labelMatch.groupValues[1])
            if (nearbyDate != null) return nearbyDate
        }
        return findDatePattern(text)
    }

    private fun findDatePattern(segment: String): String? {
        val numeric = Regex("\\b\\d{1,2}[\\/\\-.]\\d{1,2}[\\/\\-.]\\d{2,4}\\b").find(segment)
        if (numeric != null) return numeric.value

        val dayMonthYear = Regex("\\b\\d{1,2}\\s+($monthNames)\\.?,?\\s+\\d{4}\\b", RegexOption.IGNORE_CASE).find(segment)
        if (dayMonthYear != null) return dayMonthYear.value

        val monthDayYear = Regex("\\b($monthNames)\\.?\\s+\\d{1,2},?\\s+\\d{4}\\b", RegexOption.IGNORE_CASE).find(segment)
        return monthDayYear?.value
    }

    // ---------- Address ----------

    private fun extractAddress(text: String): String? {
        // Explicit label first (most reliable)
        val labelRegex = Regex(
            "(?:Address)\\s*[:\\-]\\s*(.+?)(?=\\n\\s*\\n|\\b(?:Email|Phone|Mobile|Contact|DOB|Date of Birth|Age|Gender|Nationality)\\b|$)",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        val labeled = labelRegex.find(text)?.groupValues?.get(1)?.trim()
        if (!labeled.isNullOrBlank() && labeled.length in 5..200) return labeled.trim(',', ' ', '\n')

        // Fallback: combine "R/o <place>" and "live in <place>" style fragments,
        // each stopped at the next sentence boundary - not the whole paragraph.
        val fragments = mutableListOf<String>()

        val roMatch = Regex("R\\/[Oo]\\.?\\s+([A-Za-z0-9,.\\s-]+?)(?=[.!?]|,?\\s+I\\b|$)").find(text)
        roMatch?.let {
            val fragment = it.groupValues[1].trim().trim(',', '.', ' ')
            if (fragment.isNotBlank()) fragments.add(fragment)
        }

        val liveMatch = Regex(
            "(?:I live in|live in|residing at|resident of)\\s+([A-Za-z0-9,.\\s-]+?)(?=[.!?]|,?\\s+I\\b|$)",
            RegexOption.IGNORE_CASE
        ).find(text)
        liveMatch?.let {
            val fragment = it.groupValues[1].trim().trim(',', '.', ' ')
            if (fragment.isNotBlank()) fragments.add(fragment)
        }

        if (fragments.isNotEmpty()) return fragments.distinct().joinToString(", ")

        // Last resort: a single short sentence containing a PIN code + address keyword
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
        val pinSentence = sentences.firstOrNull { s ->
            Regex("\\b\\d{6}\\b").containsMatchIn(s) &&
                    Regex("street|road|nagar|colony|sector|city|state|pin|pincode|marg|lane|apartment|block", RegexOption.IGNORE_CASE).containsMatchIn(s)
        }
        return pinSentence?.trim()
    }

    // ---------- Name ----------

    private fun extractName(text: String): String? {
        val labelRegex = Regex("(?:Full Name|Name)\\s*[:\\-]\\s*($NAME_WORD$NAME_CONTINUATION)")
        val labeled = labelRegex.find(text)
        if (labeled != null) return labeled.groupValues[1].trim()

        val phrased = Regex("(?:My name is|I am|I'm|This is)\\s+($NAME_WORD$NAME_CONTINUATION)")
        val phrasedMatch = phrased.find(text)
        if (phrasedMatch != null) return phrasedMatch.groupValues[1].trim()

        val stopWords = setOf("The", "This", "My", "I", "A", "An", "He", "She", "They", "It", "We", "You")
        val leading = Regex("^($NAME_WORD$NAME_CONTINUATION)").find(text.trim())
        if (leading != null) {
            val candidate = leading.groupValues[1].trim()
            val firstWord = candidate.split(" ").first()
            if (firstWord !in stopWords) return candidate
        }
        return null
    }

    // ---------- Father's Name (from "S/o"/"D/o", common in Indian ID/address text) ----------

    private fun extractFatherName(text: String): String? {
        val labeled = extractLabeled(text, listOf("Father's Name", "Father Name", "Father"))
        if (!labeled.isNullOrBlank()) return labeled

        val relation = Regex("[SD]\\/[Oo]\\.?\\s+($NAME_WORD$NAME_CONTINUATION)").find(text)
        return relation?.groupValues?.get(1)?.trim()
    }

    // ---------- Blood group ----------

    private fun extractBloodGroup(text: String): String? {
        val labeled = extractLabeled(text, listOf("Blood Group", "Blood group"))
        if (!labeled.isNullOrBlank()) {
            val match = Regex("\\b(AB|A|B|O)\\s*(\\+|-|positive|negative)", RegexOption.IGNORE_CASE).find(labeled)
            if (match != null) return formatBloodGroup(match)
        }
        val standalone = Regex("\\b(AB|A|B|O)\\s*(\\+|-|positive|negative)", RegexOption.IGNORE_CASE).find(text)
        return standalone?.let { formatBloodGroup(it) }
    }

    private fun formatBloodGroup(match: MatchResult): String {
        val group = match.groupValues[1].uppercase()
        val sign = match.groupValues[2].lowercase()
        val symbol = when {
            sign.startsWith("pos") || sign == "+" -> "+"
            sign.startsWith("neg") || sign == "-" -> "-"
            else -> ""
        }
        return "$group$symbol"
    }

    // ---------- Nationality ----------

    private fun extractNationality(text: String): String? {
        val labeled = extractLabeled(text, listOf("Nationality"))
        if (!labeled.isNullOrBlank()) return labeled
        for (nat in commonNationalities) {
            if (Regex("\\b${Regex.escape(nat)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) return nat
        }
        return null
    }

    // ---------- Marital Status ----------

    private fun extractMaritalStatus(text: String): String? {
        val labeled = extractLabeled(text, listOf("Marital Status", "Marital status"))
        if (!labeled.isNullOrBlank()) return labeled
        val match = Regex("\\b(unmarried|married|single|divorced|widowed|separated)\\b", RegexOption.IGNORE_CASE).find(text)
        return match?.value?.lowercase()?.replaceFirstChar { it.uppercase() }
    }

    // ---------- Occupation ----------

    private fun extractOccupation(text: String): String? {
        val labeled = extractLabeled(text, listOf("Occupation", "Profession"))
        if (!labeled.isNullOrBlank()) return labeled
        for (occ in commonOccupations) {
            if (Regex("\\b${Regex.escape(occ)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
                return occ.replaceFirstChar { it.uppercase() }
            }
        }
        return null
    }

    // ---------- Education / Qualification ----------

    private fun extractEducation(text: String): String? {
        val labeled = extractLabeled(text, listOf("Education", "Qualification"))
        if (!labeled.isNullOrBlank()) return labeled

        val classMatch = Regex("studied\\s*(?:in|up to|till)?\\s*class\\s+([A-Za-z0-9]+)", RegexOption.IGNORE_CASE).find(text)
        if (classMatch != null) return "Class ${classMatch.groupValues[1].uppercase()}"

        val degreeMatch = Regex(
            "\\b(B\\.?\\s?Tech|B\\.?\\s?A|B\\.?\\s?Sc|B\\.?\\s?Com|M\\.?\\s?Tech|M\\.?\\s?A|M\\.?\\s?Sc|M\\.?\\s?Com|MBA|Ph\\.?\\s?D)\\b",
            RegexOption.IGNORE_CASE
        ).find(text)
        return degreeMatch?.value
    }

    // ---------- Generic "Label: value" extractor used by several fields ----------

    private fun extractLabeled(text: String, labels: List<String>): String? {
        for (label in labels) {
            val regex = Regex("\\b${Regex.escape(label)}\\s*[:\\-]\\s*([^\\n,;]{1,60})", RegexOption.IGNORE_CASE)
            val match = regex.find(text)
            if (match != null) return match.groupValues[1].trim()
        }
        return null
    }
}
