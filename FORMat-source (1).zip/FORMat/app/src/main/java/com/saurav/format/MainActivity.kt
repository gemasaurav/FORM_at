package com.saurav.format

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {

    private lateinit var etInputText: EditText
    private lateinit var btnExtract: Button
    private lateinit var btnCopy: Button
    private lateinit var tvStatus: TextView
    private lateinit var resultCard: CardView

    private lateinit var rowName: View
    private lateinit var rowFatherName: View
    private lateinit var rowAge: View
    private lateinit var rowGender: View
    private lateinit var rowDob: View
    private lateinit var rowAddress: View
    private lateinit var rowEmail: View
    private lateinit var rowPhone: View
    private lateinit var rowNationality: View
    private lateinit var rowBloodGroup: View
    private lateinit var rowMaritalStatus: View
    private lateinit var rowOccupation: View
    private lateinit var rowEducation: View

    private lateinit var tvName: TextView
    private lateinit var tvFatherName: TextView
    private lateinit var tvAge: TextView
    private lateinit var tvGender: TextView
    private lateinit var tvDob: TextView
    private lateinit var tvAddress: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvPhone: TextView
    private lateinit var tvNationality: TextView
    private lateinit var tvBloodGroup: TextView
    private lateinit var tvMaritalStatus: TextView
    private lateinit var tvOccupation: TextView
    private lateinit var tvEducation: TextView

    private var lastResult: DetailExtractor.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etInputText = findViewById(R.id.etInputText)
        btnExtract = findViewById(R.id.btnExtract)
        btnCopy = findViewById(R.id.btnCopy)
        tvStatus = findViewById(R.id.tvStatus)
        resultCard = findViewById(R.id.resultCard)

        rowName = findViewById(R.id.rowName)
        rowFatherName = findViewById(R.id.rowFatherName)
        rowAge = findViewById(R.id.rowAge)
        rowGender = findViewById(R.id.rowGender)
        rowDob = findViewById(R.id.rowDob)
        rowAddress = findViewById(R.id.rowAddress)
        rowEmail = findViewById(R.id.rowEmail)
        rowPhone = findViewById(R.id.rowPhone)
        rowNationality = findViewById(R.id.rowNationality)
        rowBloodGroup = findViewById(R.id.rowBloodGroup)
        rowMaritalStatus = findViewById(R.id.rowMaritalStatus)
        rowOccupation = findViewById(R.id.rowOccupation)
        rowEducation = findViewById(R.id.rowEducation)

        tvName = findViewById(R.id.tvName)
        tvFatherName = findViewById(R.id.tvFatherName)
        tvAge = findViewById(R.id.tvAge)
        tvGender = findViewById(R.id.tvGender)
        tvDob = findViewById(R.id.tvDob)
        tvAddress = findViewById(R.id.tvAddress)
        tvEmail = findViewById(R.id.tvEmail)
        tvPhone = findViewById(R.id.tvPhone)
        tvNationality = findViewById(R.id.tvNationality)
        tvBloodGroup = findViewById(R.id.tvBloodGroup)
        tvMaritalStatus = findViewById(R.id.tvMaritalStatus)
        tvOccupation = findViewById(R.id.tvOccupation)
        tvEducation = findViewById(R.id.tvEducation)

        btnExtract.setOnClickListener { runExtraction() }
        btnCopy.setOnClickListener { copyResults() }
    }

    private fun runExtraction() {
        val input = etInputText.text.toString().trim()
        if (input.isBlank()) {
            Toast.makeText(this, getString(R.string.no_text_toast), Toast.LENGTH_SHORT).show()
            return
        }

        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etInputText.windowToken, 0)

        val result = DetailExtractor.extract(input)
        lastResult = result

        if (result.isEmpty()) {
            resultCard.visibility = View.GONE
            tvStatus.text = getString(R.string.nothing_found)
            return
        }

        tvStatus.text = ""
        setRowOrHide(rowName, tvName, result.name)
        setRowOrHide(rowFatherName, tvFatherName, result.fatherName)
        setRowOrHide(rowAge, tvAge, result.age)
        setRowOrHide(rowGender, tvGender, result.gender)
        setRowOrHide(rowDob, tvDob, result.dob)
        setRowOrHide(rowAddress, tvAddress, result.address)
        setRowOrHide(rowEmail, tvEmail, result.email)
        setRowOrHide(rowPhone, tvPhone, result.phone)
        setRowOrHide(rowNationality, tvNationality, result.nationality)
        setRowOrHide(rowBloodGroup, tvBloodGroup, result.bloodGroup)
        setRowOrHide(rowMaritalStatus, tvMaritalStatus, result.maritalStatus)
        setRowOrHide(rowOccupation, tvOccupation, result.occupation)
        setRowOrHide(rowEducation, tvEducation, result.education)

        resultCard.visibility = View.VISIBLE
    }

    private fun setRowOrHide(row: View, valueView: TextView, value: String?) {
        if (value.isNullOrBlank()) {
            row.visibility = View.GONE
        } else {
            row.visibility = View.VISIBLE
            valueView.text = value
        }
    }

    private fun copyResults() {
        val result = lastResult ?: return
        val lines = mutableListOf<String>()
        result.name?.let { lines.add("${getString(R.string.label_name)}: $it") }
        result.fatherName?.let { lines.add("${getString(R.string.label_father_name)}: $it") }
        result.age?.let { lines.add("${getString(R.string.label_age)}: $it") }
        result.gender?.let { lines.add("${getString(R.string.label_gender)}: $it") }
        result.dob?.let { lines.add("${getString(R.string.label_dob)}: $it") }
        result.address?.let { lines.add("${getString(R.string.label_address)}: $it") }
        result.email?.let { lines.add("${getString(R.string.label_email)}: $it") }
        result.phone?.let { lines.add("${getString(R.string.label_phone)}: $it") }
        result.nationality?.let { lines.add("${getString(R.string.label_nationality)}: $it") }
        result.bloodGroup?.let { lines.add("${getString(R.string.label_blood_group)}: $it") }
        result.maritalStatus?.let { lines.add("${getString(R.string.label_marital_status)}: $it") }
        result.occupation?.let { lines.add("${getString(R.string.label_occupation)}: $it") }
        result.education?.let { lines.add("${getString(R.string.label_education)}: $it") }

        if (lines.isEmpty()) return

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("FORMat results", lines.joinToString("\n"))
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
